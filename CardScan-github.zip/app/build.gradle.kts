plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.example.cardscan"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.cardscan"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    // 온디바이스 한국어 OCR (인터넷 불필요)
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    // 명함 가장자리 자동 인식 + 기울기/밝기 보정 (구글 문서 스캐너)
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")
}
