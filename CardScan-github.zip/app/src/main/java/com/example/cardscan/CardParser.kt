package com.example.cardscan

import kotlin.math.abs

/** OCR로 읽은 한 줄: 글자, 글자 높이(크기), 위치 */
data class OcrLine(val text: String, val height: Int, val top: Int, val left: Int)

data class Card(
    val name: String = "", val org: String = "", val title: String = "",
    val mobile: String = "", val tel: String = "", val email: String = "",
    val addr: String = "", val url: String = ""
)

object CardParser {
    private val emailRe = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val urlRe = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)
    private val domainRe = Regex(
        "\\b[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.(com|co\\.kr|kr|net|org|io|biz|ai)\\b(/\\S*)?",
        RegexOption.IGNORE_CASE
    )
    private val phoneRe = Regex(
        "(?<!\\d)(?:\\+?82[-.\\s]?\\(?0?\\d{1,2}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}" +
            "|\\(?0\\d{1,2}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}" +
            "|1[5-9]\\d{2}[-.\\s]?\\d{4})(?!\\d)"
    )

    // 번호 앞 라벨 (T. M. Tel Mobile 휴대폰 F. Fax 등)
    private val faxTok = setOf("f", "fax", "팩스", "팩시밀리")
    private val mobTok = setOf("m", "mobile", "mob", "cell", "c", "hp", "핸드폰", "휴대폰", "휴대전화", "모바일")

    private val titleKw = listOf(
        "대표이사", "대표", "회장", "부회장", "사장", "부사장", "전무", "상무", "이사", "본부장", "실장", "부장",
        "차장", "과장", "대리", "사원", "주임", "팀장", "팀원", "센터장", "소장", "원장", "교수", "연구원",
        "책임", "선임", "수석", "매니저", "변호사", "회계사", "Manager", "Director", "CEO", "CTO", "CFO",
        "COO", "Engineer", "Designer", "Developer", "Lead", "President", "Professor", "Researcher",
        "Specialist", "Executive", "Consultant", "Partner", "Head"
    )
    private val orgRe = Regex(
        "(주식회사|\\(주\\)|㈜|\\(유\\)|유한회사|법무법인|재단|협회|병원|대학교|연구소|학원|Co\\.|\\bInc\\b|\\bCorp|\\bLtd|\\bLLC\\b|Company|\\bGroup\\b)",
        RegexOption.IGNORE_CASE
    )
    private val engOrgRe = Regex(
        "\\b(inc|corp|co|ltd|llc|company|group|technologies|technology|solutions|systems|lab|labs|studio|bank|hospital|university)\\b",
        RegexOption.IGNORE_CASE
    )
    private val deptRe = Regex("(팀|부|실|과|본부|센터|연구소|사업부|사업단|지점|지사)$")
    private val companyWordRe = Regex("(전자|산업|건설|제약|화학|물산|은행|증권|보험|그룹|테크|시스템|소프트|랩|스튜디오|컴퍼니|상사|전기|통신|식품|약품)")
    private val addrRe = Regex(
        "(특별시|광역시|[가-힣]{1,4}(시|도)\\s?[가-힣]+(구|군|시)|[가-힣0-9]+(로|길)\\s?\\d+|\\d+(층|호)|[가-힣]+동\\s?\\d+|" +
            "\\b(Street|St\\.|Road|Rd\\.?|Avenue|Ave\\.?|Floor|Fl\\.|Tower|Bldg|Gu|Dong)\\b)",
        RegexOption.IGNORE_CASE
    )
    private val addrContRe = Regex("(층|호|빌딩|타워|센터|Tower|Bldg|Floor|\\d+F|\\bB\\d|\\d{5})", RegexOption.IGNORE_CASE)

    private fun hasTitle(s: String) = titleKw.any { s.contains(it, ignoreCase = true) }
    private fun digits(s: String) = s.filter { it.isDigit() }
    private fun isMobileNum(d: String) = d.startsWith("01") || d.startsWith("821")

    fun extractPhone(t: String): String = phoneRe.find(t)?.value?.trim() ?: t
    fun extractEmail(t: String): String =
        emailRe.find(t.replace(Regex("\\s*@\\s*"), "@"))?.value ?: t

    private fun classify(pre: String, d: String): String {
        val p = pre.lowercase().replace(Regex("h\\s*[./]\\s*p"), "hp")
        val tok = Regex("(?<![0-9a-z가-힣])([a-z가-힣]+)[\\s.:|/\\-)(]*$").find(p)?.groupValues?.get(1)
        if (tok != null && tok in faxTok) return "fax"
        if (isMobileNum(d)) return "mobile"
        if (tok != null && tok in mobTok) return "mobile"
        return "tel"
    }

    private fun splitNameTitle(t: String): Pair<String, String>? {
        val s = t.trim()
        Regex("^([가-힣]{2,4})\\s*[|/·,]?\\s*([가-힣A-Za-z ]{1,14})$").find(s)?.let { m ->
            val n = m.groupValues[1]; val ti = m.groupValues[2].trim()
            if (hasTitle(ti) && !hasTitle(n)) return n to ti
        }
        Regex("^([가-힣A-Za-z ]{1,14})\\s*[|/·,]?\\s*([가-힣]{2,4})$").find(s)?.let { m ->
            val ti = m.groupValues[1].trim(); val n = m.groupValues[2]
            if (hasTitle(ti) && !hasTitle(n)) return n to ti
        }
        val parts = s.split(Regex("\\s*[|/·]\\s*"))
        if (parts.size == 2) {
            val a = parts[0].trim(); val b = parts[1].trim()
            if (hasTitle(b) && !hasTitle(a) && a.length in 2..24) return a to b
            if (hasTitle(a) && !hasTitle(b) && b.length in 2..24) return b to a
        }
        return null
    }

    fun parse(input: List<OcrLine>): Card {
        val lines = input.map { it.copy(text = it.text.trim()) }.filter { it.text.isNotEmpty() }
        val used = BooleanArray(lines.size)
        var email = ""; var url = ""; var mobile = ""; var tel = ""; var addr = ""

        // 1) 이메일
        for (i in lines.indices) {
            val t = lines[i].text.replace(Regex("\\s*@\\s*"), "@")
            val m = emailRe.find(t)
            if (m != null && email.isEmpty()) { email = m.value; used[i] = true }
        }
        // 2) 웹사이트
        for (i in lines.indices) {
            if (used[i]) continue
            val t = lines[i].text
            if (t.contains("@")) continue
            val m = urlRe.find(t) ?: domainRe.find(t)
            if (m != null && url.isEmpty()) { url = m.value; used[i] = true }
        }
        // 3) 전화번호 (라벨 + 번호 모양으로 휴대폰/전화/팩스 구분)
        for (i in lines.indices) {
            if (used[i]) continue
            val t = lines[i].text
            val ms = phoneRe.findAll(t).toList()
            if (ms.isEmpty()) continue
            var prevEnd = 0
            for (m in ms) {
                val pre = t.substring(prevEnd, m.range.first)
                prevEnd = m.range.last + 1
                val num = m.value.trim()
                when (classify(pre, digits(num))) {
                    "fax" -> {}
                    "mobile" -> if (mobile.isEmpty()) mobile = num
                    else -> if (tel.isEmpty()) tel = num
                }
            }
            used[i] = true
        }
        // 4) 주소 (다음 줄이 이어지면 합침)
        for (i in lines.indices) {
            if (used[i] || addr.isNotEmpty()) continue
            val t = lines[i].text
            val labeled = Regex("^(주소|address|add)\\s*[.:)]", RegexOption.IGNORE_CASE).containsMatchIn(t)
            if (labeled || (t.length >= 8 && addrRe.containsMatchIn(t))) {
                addr = t; used[i] = true
                if (i + 1 < lines.size && !used[i + 1] && addrContRe.containsMatchIn(lines[i + 1].text)) {
                    addr += " " + lines[i + 1].text; used[i + 1] = true
                }
            }
        }
        addr = addr.replace(Regex("^(주소|address|add|a)\\s*[.:)]\\s*", RegexOption.IGNORE_CASE), "").trim()

        // 5) 이름+직책이 한 줄에 같이 있는 경우
        var name = ""; var title = ""; var titleIdx = -1
        for (i in lines.indices) {
            if (used[i] || name.isNotEmpty()) continue
            val sp = splitNameTitle(lines[i].text)
            if (sp != null) { name = sp.first; title = sp.second; used[i] = true; titleIdx = i }
        }
        // 6) 직책
        if (title.isEmpty()) {
            for (i in lines.indices) {
                if (used[i]) continue
                val t = lines[i].text
                if (t.length <= 30 && hasTitle(t)) { title = t; used[i] = true; titleIdx = i; break }
            }
        }
        // 7) 이름: 글자 수, 직책과의 거리, 글자 크기로 점수 매김
        if (name.isEmpty()) {
            val maxH = (lines.filterIndexed { i, _ -> !used[i] }.maxOfOrNull { it.height } ?: 1).coerceAtLeast(1)
            var best = -1; var bestScore = -99.0
            for (i in lines.indices) {
                if (used[i]) continue
                var t = lines[i].text
                if (Regex("^([가-힣]\\s){1,3}[가-힣]$").matches(t)) t = t.replace(" ", "")
                val isKo = Regex("^[가-힣]{2,4}$").matches(t) && !hasTitle(t) && !orgRe.containsMatchIn(t)
                val isEn = Regex("^[A-Za-z][A-Za-z.'-]*(\\s+[A-Za-z][A-Za-z.'-]*){1,2}$").matches(t) &&
                    !engOrgRe.containsMatchIn(t) && !hasTitle(t)
                if (!isKo && !isEn) continue
                var s = if (isKo) (when (t.length) { 3 -> 3.0; 2 -> 1.0; else -> 0.0 }) else 1.0
                if (isKo && t.length == 4 && Regex("^(남궁|황보|제갈|선우|독고|사공|서문|동방)").containsMatchIn(t)) s += 3.0
                if (isKo && t.length >= 3 && deptRe.containsMatchIn(t)) s -= 3.0
                if (isKo && companyWordRe.containsMatchIn(t)) s -= 3.0
                if (titleIdx >= 0 && abs(i - titleIdx) <= 1) s += 2.0
                s += lines[i].height.toDouble() / maxH * 2.0
                if (s > bestScore) { bestScore = s; best = i }
            }
            if (best >= 0 && bestScore >= 2.0) {
                var t = lines[best].text
                if (Regex("^([가-힣]\\s){1,3}[가-힣]$").matches(t)) t = t.replace(" ", "")
                name = t; used[best] = true
            }
        }
        // 8) 회사: 회사 키워드가 있는 줄, 없으면 가장 큰 글자
        var org = ""
        var bi = -1; var bh = -1
        for (i in lines.indices) {
            if (used[i]) continue
            if (orgRe.containsMatchIn(lines[i].text) && lines[i].height > bh) { bi = i; bh = lines[i].height }
        }
        if (bi < 0) {
            for (i in lines.indices) {
                if (used[i]) continue
                val t = lines[i].text
                if (t.length < 2 || t.count { it.isDigit() } > t.length / 2) continue
                if (deptRe.containsMatchIn(t) && t.length <= 8) continue
                if (lines[i].height > bh) { bi = i; bh = lines[i].height }
            }
        }
        if (bi >= 0) { org = lines[bi].text; used[bi] = true }

        return Card(name, org, title, mobile, tel, email, addr, url)
    }
}
