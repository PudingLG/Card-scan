package com.example.cardscan

data class Card(
    val name: String = "", val org: String = "", val title: String = "",
    val mobile: String = "", val tel: String = "", val email: String = "",
    val addr: String = "", val url: String = ""
)

object CardParser {
    private val emailRe = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val urlRe = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)
    private val phoneRe = Regex("(\\+82[-\\s]?)?\\(?0?\\d{1,2}\\)?[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}")
    private val titleKw = listOf(
        "대표", "이사", "부장", "차장", "과장", "대리", "사원", "팀장", "실장", "본부장", "사장", "부사장",
        "교수", "연구원", "책임", "선임", "수석", "매니저", "Manager", "Director", "CEO", "CTO", "Engineer",
        "Designer", "Developer", "Lead", "President"
    )
    private val orgKw = listOf("주식회사", "(주)", "㈜", "Co.", "Inc", "Corp", "Ltd", "회사", "병원", "대학교", "연구소", "법무법인", "재단", "협회")
    private val addrRe = Regex("([가-힣]+(시|도|구|군)\\s).*\\d|[가-힣0-9]+(로|길)\\s?\\d+")

    fun parse(raw: String): Card {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val used = mutableSetOf<String>()

        val email = lines.firstNotNullOfOrNull { emailRe.find(it)?.value }.orEmpty()
        val url = lines.firstNotNullOfOrNull { l -> urlRe.find(l)?.value?.takeIf { !l.contains("@") } }.orEmpty()

        var mobile = ""; var tel = ""
        for (l in lines) {
            if (l.contains("fax", true) || l.contains("팩스") || l.startsWith("F ", true) || l.startsWith("F.", true)) continue
            val m = phoneRe.find(l) ?: continue
            val p = m.value.trim()
            val digits = p.filter { it.isDigit() }
            if (digits.length < 8) continue
            val isMobile = digits.startsWith("010") || digits.startsWith("8210") || digits.startsWith("01")
            if (isMobile && mobile.isEmpty()) { mobile = p; used += l }
            else if (!isMobile && tel.isEmpty()) { tel = p; used += l }
        }
        if (email.isNotEmpty()) used += lines.filter { it.contains(email) }
        if (url.isNotEmpty()) used += lines.filter { it.contains(url) }

        val addr = lines.firstOrNull { it !in used && it.length > 8 && addrRe.containsMatchIn(it) }.orEmpty()
        if (addr.isNotEmpty()) used += addr
        val rest = lines.filter { it !in used }

        val title = rest.firstOrNull { l -> titleKw.any { l.contains(it, true) } && l.length <= 20 }.orEmpty()
        val org = rest.firstOrNull { l -> orgKw.any { l.contains(it, true) } }
            ?: rest.firstOrNull { it != title && !it.matches(Regex("^[가-힣]{2,4}$")) }.orEmpty()
        val name = rest.firstOrNull { it.matches(Regex("^[가-힣]{2,4}$")) && it != org && it != title }
            ?: rest.firstOrNull { it != org && it != title && it.length in 2..20 }.orEmpty()

        return Card(name, org, title, mobile, tel, email, addr, url)
    }
}
