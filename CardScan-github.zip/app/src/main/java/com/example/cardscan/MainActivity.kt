package com.example.cardscan

import android.Manifest
import android.content.ContentProviderOperation
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds as K
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var photo by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("명함을 촬영해 주세요.") }
    var c by remember { mutableStateOf(Card()) }
    var scanned by remember { mutableStateOf(false) }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = photo
        if (ok && uri != null) {
            status = "명함을 읽는 중…"
            val rec = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            rec.process(InputImage.fromFilePath(ctx, uri))
                .addOnSuccessListener { r ->
                    c = CardParser.parse(r.text); scanned = true
                    status = "읽기 완료! 내용을 확인하고 저장하세요."
                }
                .addOnFailureListener { status = "읽기 실패: ${it.message}" }
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) doSave(ctx, c) else "연락처 저장 권한이 필요해요."
    }

    Column(
        Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("📇 명함 스캐너", style = MaterialTheme.typography.headlineSmall)
        Button(
            onClick = {
                val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
                val f = File.createTempFile("card", ".jpg", dir)
                val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                photo = uri; camera.launch(uri)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("📷 명함 촬영") }
        Text(status)

        if (scanned) {
            Field("이름", c.name) { c = c.copy(name = it) }
            Field("회사", c.org) { c = c.copy(org = it) }
            Field("직책", c.title) { c = c.copy(title = it) }
            Field("휴대폰", c.mobile) { c = c.copy(mobile = it) }
            Field("전화", c.tel) { c = c.copy(tel = it) }
            Field("이메일", c.email) { c = c.copy(email = it) }
            Field("주소", c.addr) { c = c.copy(addr = it) }
            Field("웹사이트", c.url) { c = c.copy(url = it) }
            Button(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CONTACTS)
                        == PackageManager.PERMISSION_GRANTED) status = doSave(ctx, c)
                    else permission.launch(Manifest.permission.WRITE_CONTACTS)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("💾 주소록에 저장") }
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) =
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())

fun doSave(ctx: Context, c: Card): String = try {
    saveContact(ctx, c); "✅ ${c.name.ifEmpty { "연락처" }} 님을 주소록에 저장했어요."
} catch (e: Exception) { "저장 실패: ${e.message}" }

fun saveContact(ctx: Context, c: Card) {
    val ops = ArrayList<ContentProviderOperation>()
    ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build()

    fun row(mime: String, vararg kv: Pair<String, Any?>) {
        val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, mime)
        kv.forEach { (k, v) -> b.withValue(k, v) }
        ops += b.build()
    }
    if (c.name.isNotBlank()) row(K.StructuredName.CONTENT_ITEM_TYPE, K.StructuredName.DISPLAY_NAME to c.name)
    if (c.org.isNotBlank() || c.title.isNotBlank())
        row(K.Organization.CONTENT_ITEM_TYPE, K.Organization.COMPANY to c.org, K.Organization.TITLE to c.title)
    if (c.mobile.isNotBlank()) row(K.Phone.CONTENT_ITEM_TYPE, K.Phone.NUMBER to c.mobile, K.Phone.TYPE to K.Phone.TYPE_MOBILE)
    if (c.tel.isNotBlank()) row(K.Phone.CONTENT_ITEM_TYPE, K.Phone.NUMBER to c.tel, K.Phone.TYPE to K.Phone.TYPE_WORK)
    if (c.email.isNotBlank()) row(K.Email.CONTENT_ITEM_TYPE, K.Email.ADDRESS to c.email, K.Email.TYPE to K.Email.TYPE_WORK)
    if (c.addr.isNotBlank()) row(K.StructuredPostal.CONTENT_ITEM_TYPE, K.StructuredPostal.FORMATTED_ADDRESS to c.addr, K.StructuredPostal.TYPE to K.StructuredPostal.TYPE_WORK)
    if (c.url.isNotBlank()) row(K.Website.CONTENT_ITEM_TYPE, K.Website.URL to c.url)
    ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
}
