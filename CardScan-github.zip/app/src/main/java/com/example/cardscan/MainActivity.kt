package com.example.cardscan

import android.Manifest
import android.app.Activity
import android.content.ContentProviderOperation
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds as K
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var photo by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("명함을 스캔해 주세요.") }
    var c by remember { mutableStateOf(Card()) }
    var scanned by remember { mutableStateOf(false) }
    var rawLines by remember { mutableStateOf<List<String>>(emptyList()) }
    var picked by remember { mutableStateOf<String?>(null) }

    val runOcr: (Uri) -> Unit = { uri ->
        status = "명함을 읽는 중…"
        try {
            val rec = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            rec.process(InputImage.fromFilePath(ctx, uri))
                .addOnSuccessListener { r ->
                    val ol = r.textBlocks.flatMap { b ->
                        b.lines.map { l ->
                            val bb = l.boundingBox
                            OcrLine(l.text, bb?.height() ?: 0, bb?.top ?: 0, bb?.left ?: 0)
                        }
                    }
                    c = CardParser.parse(ol)
                    rawLines = ol.map { it.text.trim() }.filter { it.isNotEmpty() }
                    scanned = true
                    status = "읽기 완료! 틀린 칸은 직접 고치거나, 아래 글자를 눌러 칸을 지정하세요."
                }
                .addOnFailureListener { status = "읽기 실패: ${it.message}" }
        } catch (e: Exception) {
            status = "읽기 실패: ${e.message}"
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = photo
        if (ok && uri != null) runOcr(uri)
    }
    val launchCamera: () -> Unit = {
        val dir = File(ctx.cacheDir, "images").apply { mkdirs() }
        val f = File.createTempFile("card", ".jpg", dir)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        photo = uri
        camera.launch(uri)
    }
    val scanner = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val r = GmsDocumentScanningResult.fromActivityResultIntent(res.data)
            val uri = r?.pages?.firstOrNull()?.imageUri
            if (uri != null) runOcr(uri) else status = "스캔 결과를 받지 못했어요."
        } else status = "스캔이 취소되었어요."
    }
    val startScan: () -> Unit = {
        val act = ctx as? Activity
        if (act == null) {
            launchCamera()
        } else {
            val opts = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(1)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_BASE)
                .build()
            GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
                .addOnSuccessListener { sender ->
                    scanner.launch(IntentSenderRequest.Builder(sender).build())
                }
                .addOnFailureListener {
                    status = "문서 스캐너를 쓸 수 없어 기본 카메라로 전환해요."
                    launchCamera()
                }
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) doSave(ctx, c) else "연락처 저장 권한이 필요해요."
    }

    Column(
        Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("📇 명함 스캐너", style = MaterialTheme.typography.headlineSmall)
        Button(onClick = { startScan() }, modifier = Modifier.fillMaxWidth()) { Text("📷 명함 스캔") }
        TextButton(onClick = { launchCamera() }) { Text("기본 카메라로 찍기") }
        Text(status)

        if (scanned) {
            Field("이름", c.name) { c = c.copy(name = it) }
            Field("회사", c.org) { c = c.copy(org = it) }
            Field("직책", c.title) { c = c.copy(title = it) }
            Field("휴대폰", c.mobile) { c = c.copy(mobile = it) }
            Field("전화", c.tel) { c = c.copy(tel = it) }
            Field("이메일", c.email) { c = c.copy(email = it) }
            Field("주소", c.addr) { c = c.copy(addr = it) }
            Field("웹사이트", c.url) { c = c.copy(url = it) }
            Button(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CONTACTS)
                        == PackageManager.PERMISSION_GRANTED) status = doSave(ctx, c)
                    else permission.launch(Manifest.permission.WRITE_CONTACTS)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("💾 주소록에 저장") }

            if (rawLines.isNotEmpty()) {
                Text("인식된 글자 (눌러서 칸 지정)", style = MaterialTheme.typography.titleSmall)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    rawLines.forEach { line ->
                        AssistChip(onClick = { picked = line }, label = { Text(line) })
                    }
                }
            }
        }
    }

    picked?.let { p ->
        AlertDialog(
            onDismissRequest = { picked = null },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picked = null }) { Text("취소") } },
            title = { Text("어느 칸에 넣을까요?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("이름", "회사", "직책", "휴대폰", "전화", "이메일", "주소", "웹사이트").forEach { f ->
                            AssistChip(onClick = { c = assign(c, f, p); picked = null }, label = { Text(f) })
                        }
                    }
                }
            }
        )
    }
}

fun assign(c: Card, field: String, raw: String): Card {
    val t = raw.trim()
    return when (field) {
        "이름" -> c.copy(name = t)
        "회사" -> c.copy(org = t)
        "직책" -> c.copy(title = t)
        "휴대폰" -> c.copy(mobile = CardParser.extractPhone(t))
        "전화" -> c.copy(tel = CardParser.extractPhone(t))
        "이메일" -> c.copy(email = CardParser.extractEmail(t))
        "주소" -> c.copy(addr = if (c.addr.isEmpty()) t else if (c.addr.contains(t)) c.addr else c.addr + " " + t)
        "웹사이트" -> c.copy(url = t)
        else -> c
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) =
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())

fun doSave(ctx: Context, c: Card): String = try {
    saveContact(ctx, c); "✅ ${c.name.ifEmpty { "연락처" }} 님을 주소록에 저장했어요."
} catch (e: Exception) { "저장 실패: ${e.message}" }

fun saveContact(ctx: Context, c: Card) {
    val ops = ArrayList<ContentProviderOperation>()
    ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build()

    fun row(mime: String, vararg kv: Pair<String, Any?>) {
        val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, mime)
        kv.forEach { (k, v) -> b.withValue(k, v) }
        ops += b.build()
    }
    if (c.name.isNotBlank()) row(K.StructuredName.CONTENT_ITEM_TYPE, K.StructuredName.DISPLAY_NAME to c.name)
    if (c.org.isNotBlank() || c.title.isNotBlank())
        row(K.Organization.CONTENT_ITEM_TYPE, K.Organization.COMPANY to c.org, K.Organization.TITLE to c.title)
    if (c.mobile.isNotBlank()) row(K.Phone.CONTENT_ITEM_TYPE, K.Phone.NUMBER to c.mobile, K.Phone.TYPE to K.Phone.TYPE_MOBILE)
    if (c.tel.isNotBlank()) row(K.Phone.CONTENT_ITEM_TYPE, K.Phone.NUMBER to c.tel, K.Phone.TYPE to K.Phone.TYPE_WORK)
    if (c.email.isNotBlank()) row(K.Email.CONTENT_ITEM_TYPE, K.Email.ADDRESS to c.email, K.Email.TYPE to K.Email.TYPE_WORK)
    if (c.addr.isNotBlank()) row(K.StructuredPostal.CONTENT_ITEM_TYPE, K.StructuredPostal.FORMATTED_ADDRESS to c.addr, K.StructuredPostal.TYPE to K.StructuredPostal.TYPE_WORK)
    if (c.url.isNotBlank()) row(K.Website.CONTENT_ITEM_TYPE, K.Website.URL to c.url)
    ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
}
